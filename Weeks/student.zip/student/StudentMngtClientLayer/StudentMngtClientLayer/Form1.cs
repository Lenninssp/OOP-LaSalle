using StudentMngtBusLayer;

namespace StudentMngtClientLayer
{
    public partial class Form1 : Form
    {

        List<Student> listOfStudents = new List<Student>;
        List<Student> listOfFiles = new List<Student>;


        public Form1()
        {
            InitializeComponent();
        }

        private void showStudent_Click(object sender, EventArgs e)
        {

        }

        private void Serialize_Click(object sender, EventArgs e)
        {

        }

        private void Deserialize_Click(object sender, EventArgs e)
        {

        }
    }
}
