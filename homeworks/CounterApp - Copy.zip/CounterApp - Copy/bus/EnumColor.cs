namespace CounterApp.bus
{
    public enum EnumColor{
        RED,
        WHITE,
        YELLOW,
        BLUE,
        NONE
    }
}